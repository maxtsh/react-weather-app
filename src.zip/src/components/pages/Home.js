import React, { useContext } from 'react';

import { WeatherContext } from '../../context/weatherContext';


function Home() {
    const { dispatch } = useContext(WeatherContext);

    return (
        <div>
            <h1>Home</h1>   
        </div>
    )
};
export default Home;