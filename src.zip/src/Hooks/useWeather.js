import { useState, useEffect } from 'react';
import axios from 'axios';

function useWeather(){
    const [state, setState] = useState();
    const API_KEY = "8830cd81f73deb943fa440272e6cb704";
    const url = `https://api.openweathermap.org/data/2.5/weather?q=Berlin&appid=${API_KEY}`;

    useEffect(() => {
        async function getWeather(){
            try{
                const res = await axios.get(url);
                setState(res.data);

            }catch(err){
                console.log(err);
            }
        }
        getWeather();
    }, [state, url]);
    
    return state;
};
export default useWeather;