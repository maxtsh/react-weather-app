import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';

// Providers
import { weatherProvider } from './context/weatherContext';

// Pages
import Home from './components/pages/Home';



function App() {
  return (
    <Router>
      <Switch>
        <weatherProvider>
          <Route exact path="/" component={Home} />
        </weatherProvider>
      </Switch>
    </Router>
  );
};
export default App;