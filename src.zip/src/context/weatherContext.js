import React, { createContext, useReducer } from 'react';
import weatherReducer from '../reducers/weatherReducer';

const initialWeather = {
    weather: null,
    loading: true,
    error: null
};

export const WeatherContext = createContext();

export function weatherProvider (props) {
    const [weather, dispatch] = useReducer(weatherReducer, initialWeather);

    return(
        <WeatherContext.Provider value={{weather, dispatch}}>
            {props.children}
        </WeatherContext.Provider>
    )
};